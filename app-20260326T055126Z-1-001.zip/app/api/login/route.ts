import { NextResponse } from "next/server";
import { authCookieOptions, createSessionValue, SESSION_COOKIE } from "@/lib/auth";

export async function POST(req: Request) {
  const { password } = await req.json().catch(() => ({ password: "" }));
  const memberPassword = process.env.AUTH_PASSWORD;
  const adminPassword = process.env.ADMIN_PASSWORD;

  if (!memberPassword) {
    return NextResponse.json({ error: "AUTH_PASSWORD is not set" }, { status: 500 });
  }

  if (!password) {
    return NextResponse.json({ error: "Password is required" }, { status: 400 });
  }

  let role: "member" | "admin" | null = null;

  if (adminPassword && password === adminPassword) {
    role = "admin";
  } else if (password === memberPassword) {
    role = "member";
  }

  if (!role) {
    return NextResponse.json({ error: "Invalid password" }, { status: 401 });
  }

  const session = createSessionValue(role);
  const res = NextResponse.json({ ok: true, role });
  res.cookies.set(SESSION_COOKIE, session, authCookieOptions());
  return res;
}
