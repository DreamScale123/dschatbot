import { NextResponse } from "next/server";
import { isAdminFromCookies } from "@/lib/auth";

const ALLOWED_MIME = new Set([
  "application/pdf",
  "text/plain",
  "text/markdown",
  "text/csv",
  "application/json",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
]);

export async function GET() {
  if (!isAdminFromCookies()) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  const vectorStoreId = process.env.OPENAI_VECTOR_STORE_ID;
  if (!apiKey) {
    return NextResponse.json({ error: "OPENAI_API_KEY is not set" }, { status: 500 });
  }
  if (!vectorStoreId) {
    return NextResponse.json({ error: "OPENAI_VECTOR_STORE_ID is not set" }, { status: 400 });
  }

  const response = await fetch(`https://api.openai.com/v1/vector_stores/${vectorStoreId}/files`, {
    headers: { Authorization: `Bearer ${apiKey}` }
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    return NextResponse.json({ error: err.error?.message || "Failed to load files" }, { status: 500 });
  }

  const data = await response.json();
  return NextResponse.json({ files: data.data || [] });
}

export async function POST(req: Request) {
  if (!isAdminFromCookies()) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  const vectorStoreId = process.env.OPENAI_VECTOR_STORE_ID;
  if (!apiKey) {
    return NextResponse.json({ error: "OPENAI_API_KEY is not set" }, { status: 500 });
  }
  if (!vectorStoreId) {
    return NextResponse.json({ error: "OPENAI_VECTOR_STORE_ID is not set" }, { status: 400 });
  }

  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "File is required" }, { status: 400 });
  }

  if (file.size > 50 * 1024 * 1024) {
    return NextResponse.json({ error: "File too large. Use files under 50MB." }, { status: 400 });
  }

  if (file.type && !ALLOWED_MIME.has(file.type)) {
    return NextResponse.json({ error: "Unsupported file type" }, { status: 400 });
  }

  const uploadForm = new FormData();
  uploadForm.append("purpose", "assistants");
  uploadForm.append("file", file, file.name);

  const uploadRes = await fetch("https://api.openai.com/v1/files", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: uploadForm
  });

  if (!uploadRes.ok) {
    const err = await uploadRes.json().catch(() => ({}));
    return NextResponse.json({ error: err.error?.message || "File upload failed" }, { status: 500 });
  }

  const uploaded = await uploadRes.json();
  const fileId = uploaded.id;

  const attachRes = await fetch(`https://api.openai.com/v1/vector_stores/${vectorStoreId}/files`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({ file_id: fileId })
  });

  if (!attachRes.ok) {
    const err = await attachRes.json().catch(() => ({}));
    return NextResponse.json({ error: err.error?.message || "Failed to attach file" }, { status: 500 });
  }

  const attached = await attachRes.json();
  return NextResponse.json({ ok: true, file: attached });
}
