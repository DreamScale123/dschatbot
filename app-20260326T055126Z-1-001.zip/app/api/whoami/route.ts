import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";

export async function GET() {
  const session = getSession();
  if (!session) {
    return NextResponse.json({ authed: false });
  }
  return NextResponse.json({ authed: true, role: session.role });
}
