"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type GameStatus = "ready" | "running" | "paused" | "ended";

type Entity = {
  id: number;
  x: number;
  y: number;
  r: number;
};

type Rock = Entity & { strength: number };

type Player = {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  health: number;
};

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

const randomBetween = (min: number, max: number) => min + Math.random() * (max - min);

const makeEntity = (id: number, width: number, height: number, radius: number): Entity => ({
  id,
  x: randomBetween(radius + 12, width - radius - 12),
  y: randomBetween(radius + 12, height - radius - 12),
  r: radius,
});

const makeRock = (id: number, width: number, height: number): Rock => ({
  ...makeEntity(id, width, height, randomBetween(14, 22)),
  strength: randomBetween(0.6, 1.2),
});

const TARGET_SCORE = 18;
const ROUND_SECONDS = 60;

export default function HomePage() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const frameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number | null>(null);
  const keysRef = useRef<Record<string, boolean>>({});
  const bugsRef = useRef<Entity[]>([]);
  const waterRef = useRef<Entity[]>([]);
  const rocksRef = useRef<Rock[]>([]);
  const playerRef = useRef<Player>({ x: 220, y: 180, r: 16, vx: 0, vy: 0, health: 3 });
  const tongueRef = useRef<{ active: boolean; timer: number }>({ active: false, timer: 0 });
  const [status, setStatus] = useState<GameStatus>("ready");
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(ROUND_SECONDS);
  const [health, setHealth] = useState(3);
  const [message, setMessage] = useState("Scout the dunes and snack on bugs.");

  const canvasSize = useMemo(() => ({ width: 720, height: 460 }), []);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      keysRef.current[key] = true;
      if (event.code === "Space") {
        keysRef.current["space"] = true;
      }
      if (event.key === " ") {
        event.preventDefault();
      }
    };
    const handleKeyUp = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      keysRef.current[key] = false;
      if (event.code === "Space") {
        keysRef.current["space"] = false;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);

  useEffect(() => {
    if (status !== "running") {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      return;
    }

    const tick = (timestamp: number) => {
      const last = lastTimeRef.current ?? timestamp;
      const delta = Math.min((timestamp - last) / 1000, 0.05);
      lastTimeRef.current = timestamp;
      updateGame(delta);
      drawScene();
      frameRef.current = requestAnimationFrame(tick);
    };

    frameRef.current = requestAnimationFrame(tick);

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const observer = new ResizeObserver(() => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const rect = parent.getBoundingClientRect();
      const scale = Math.min(rect.width / canvasSize.width, rect.height / canvasSize.height, 1);
      canvas.style.width = `${canvasSize.width * scale}px`;
      canvas.style.height = `${canvasSize.height * scale}px`;
    });

    observer.observe(canvas.parentElement ?? canvas);
    return () => observer.disconnect();
  }, [canvasSize]);

  const resetRound = () => {
    setStatus("ready");
    setScore(0);
    setHealth(3);
    setTimeLeft(ROUND_SECONDS);
    setMessage("Scout the dunes and snack on bugs.");
    lastTimeRef.current = null;

    const width = canvasSize.width;
    const height = canvasSize.height;
    playerRef.current = { x: width / 2, y: height / 2, r: 16, vx: 0, vy: 0, health: 3 };

    bugsRef.current = Array.from({ length: 10 }).map((_, index) =>
      makeEntity(index + 1, width, height, randomBetween(6, 9)),
    );
    waterRef.current = Array.from({ length: 3 }).map((_, index) =>
      makeEntity(index + 201, width, height, randomBetween(7, 10)),
    );
    rocksRef.current = Array.from({ length: 6 }).map((_, index) =>
      makeRock(index + 101, width, height),
    );
    tongueRef.current = { active: false, timer: 0 };
  };

  const updateGame = (delta: number) => {
    if (status !== "running") return;

    setTimeLeft((prev) => {
      const next = Math.max(prev - delta, 0);
      if (next === 0) {
        endGame();
      }
      return next;
    });

    const player = playerRef.current;
    const width = canvasSize.width;
    const height = canvasSize.height;

    const speed = 140;
    const xAxis = (keysRef.current["a"] || keysRef.current["arrowleft"] ? -1 : 0) +
      (keysRef.current["d"] || keysRef.current["arrowright"] ? 1 : 0);
    const yAxis = (keysRef.current["w"] || keysRef.current["arrowup"] ? -1 : 0) +
      (keysRef.current["s"] || keysRef.current["arrowdown"] ? 1 : 0);

    const length = Math.hypot(xAxis, yAxis) || 1;
    player.vx = (xAxis / length) * speed;
    player.vy = (yAxis / length) * speed;

    player.x = clamp(player.x + player.vx * delta, player.r + 6, width - player.r - 6);
    player.y = clamp(player.y + player.vy * delta, player.r + 6, height - player.r - 6);

    if ((keysRef.current[" "] || keysRef.current["space"]) && !tongueRef.current.active) {
      tongueRef.current = { active: true, timer: 0.22 };
    }

    if (tongueRef.current.active) {
      tongueRef.current.timer -= delta;
      if (tongueRef.current.timer <= 0) {
        tongueRef.current.active = false;
      }
    }

    const tongueReach = tongueRef.current.active ? 56 : 0;
    const before = bugsRef.current.length;
    bugsRef.current = bugsRef.current.filter((bug) => {
      const distance = Math.hypot(bug.x - player.x, bug.y - player.y);
      return distance > bug.r + player.r + Math.max(10, tongueReach);
    });
    const eaten = before - bugsRef.current.length;
    if (eaten > 0) {
      setScore((prev) => prev + eaten);
      setMessage(tongueReach > 0 ? "Crunch! Protein boost." : "Snagged a bug.");
    }

    bugsRef.current.forEach((bug) => {
      bug.x += Math.sin((bug.id + performance.now() / 1000) * 1.2) * delta * 20;
      bug.y += Math.cos((bug.id + performance.now() / 1000) * 1.1) * delta * 18;
      bug.x = clamp(bug.x, bug.r + 6, width - bug.r - 6);
      bug.y = clamp(bug.y, bug.r + 6, height - bug.r - 6);
    });

    waterRef.current.forEach((drop) => {
      const distance = Math.hypot(drop.x - player.x, drop.y - player.y);
      if (distance < drop.r + player.r + 6) {
        drop.x = randomBetween(drop.r + 12, width - drop.r - 12);
        drop.y = randomBetween(drop.r + 12, height - drop.r - 12);
        if (player.health < 5) {
          player.health += 1;
          setHealth(player.health);
          setMessage("Hydrated and happy.");
        }
      }
    });

    let hit = false;
    rocksRef.current.forEach((rock) => {
      const distance = Math.hypot(rock.x - player.x, rock.y - player.y);
      if (distance < rock.r + player.r + 4) {
        hit = true;
        const angle = Math.atan2(player.y - rock.y, player.x - rock.x);
        player.x += Math.cos(angle) * 18 * rock.strength;
        player.y += Math.sin(angle) * 18 * rock.strength;
      }
    });

    if (hit) {
      player.health = Math.max(player.health - 1, 0);
      setHealth(player.health);
      setMessage("Ouch. Rocks are hotter than they look.");
    }

    if (player.health <= 0) {
      endGame();
    }

    if (score >= TARGET_SCORE) {
      endGame(true);
    }

    if (bugsRef.current.length < 6) {
      const id = Math.floor(Math.random() * 10000) + 500;
      bugsRef.current.push(makeEntity(id, width, height, randomBetween(6, 9)));
    }
  };

  const drawScene = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const width = canvasSize.width;
    const height = canvasSize.height;

    ctx.clearRect(0, 0, width, height);

    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, "#f2c777");
    gradient.addColorStop(1, "#d68b4a");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = "rgba(255, 255, 255, 0.08)";
    for (let i = 0; i < 20; i += 1) {
      ctx.beginPath();
      ctx.ellipse(40 + i * 32, 40 + (i % 5) * 18, 28, 10, 0.4, 0, Math.PI * 2);
      ctx.fill();
    }

    rocksRef.current.forEach((rock) => {
      ctx.fillStyle = "#7b4d2c";
      ctx.beginPath();
      ctx.arc(rock.x, rock.y, rock.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.15)";
      ctx.beginPath();
      ctx.arc(rock.x - 3, rock.y - 3, rock.r * 0.4, 0, Math.PI * 2);
      ctx.fill();
    });

    bugsRef.current.forEach((bug) => {
      ctx.fillStyle = "#3e2c1a";
      ctx.beginPath();
      ctx.arc(bug.x, bug.y, bug.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#f0b34b";
      ctx.beginPath();
      ctx.arc(bug.x - 2, bug.y - 2, bug.r * 0.4, 0, Math.PI * 2);
      ctx.fill();
    });

    waterRef.current.forEach((drop) => {
      ctx.fillStyle = "#5dd6ff";
      ctx.beginPath();
      ctx.arc(drop.x, drop.y, drop.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.65)";
      ctx.beginPath();
      ctx.arc(drop.x - 2, drop.y - 2, drop.r * 0.4, 0, Math.PI * 2);
      ctx.fill();
    });

    const player = playerRef.current;
    const facing = player.vx >= 0 ? 1 : -1;
    const headX = player.x + facing * 12;
    const headY = player.y - 6;

    ctx.fillStyle = "#b56b2a";
    ctx.beginPath();
    ctx.ellipse(player.x, player.y, 20, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#c9853c";
    ctx.beginPath();
    ctx.ellipse(headX, headY, 12, 9, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "#9a5a26";
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(player.x - facing * 6, player.y + 6);
    ctx.lineTo(player.x - facing * 22, player.y + 12);
    ctx.lineTo(player.x - facing * 32, player.y + 18);
    ctx.stroke();

    ctx.fillStyle = "#8b4f22";
    ctx.beginPath();
    ctx.ellipse(player.x - 8, player.y + 10, 6, 4, 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(player.x + 6, player.y + 10, 6, 4, -0.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#2b1b0f";
    ctx.beginPath();
    ctx.arc(headX + facing * 3, headY - 2, 2.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(headX - facing * 2, headY - 2, 2.6, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#a05e2a";
    ctx.beginPath();
    ctx.moveTo(player.x - 6, player.y - 12);
    ctx.lineTo(player.x - 2, player.y - 18);
    ctx.lineTo(player.x + 2, player.y - 12);
    ctx.closePath();
    ctx.fill();

    if (tongueRef.current.active) {
      ctx.strokeStyle = "#ff6b6b";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(headX, headY);
      ctx.lineTo(headX + facing * 52, headY);
      ctx.stroke();
    }
  };

  const startGame = () => {
    resetRound();
    setStatus("running");
  };

  const pauseGame = () => {
    if (status === "running") {
      setStatus("paused");
      setMessage("Taking a basking break.");
    } else if (status === "paused") {
      setStatus("running");
      setMessage("Back on the hunt.");
    }
  };

  const endGame = (won = false) => {
    setStatus("ended");
    setMessage(won ? "Legendary hunter!" : "The sun sets. Try again.");
  };

  return (
    <main className="game-page">
      <section className="game-shell">
        <header className="game-header">
          <div>
            <p className="game-kicker">Bearded Dragon Arcade</p>
            <h1>Desert Dash</h1>
            <p className="game-subtitle">
              Nibble the bugs, avoid the scorching rocks, and stay hydrated before the sunset.
            </p>
          </div>
          <div className="game-stats">
            <div>
              <span className="stat-label">Score</span>
              <span className="stat-value">{score}</span>
            </div>
            <div>
              <span className="stat-label">Health</span>
              <span className="stat-value">{"\u2764".repeat(health)}</span>
            </div>
            <div>
              <span className="stat-label">Time</span>
              <span className="stat-value">{Math.ceil(timeLeft)}s</span>
            </div>
          </div>
        </header>

        <div className="game-stage">
          <div className="game-canvas-wrap">
            <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} />
          </div>
          <div className="game-panel">
            <p className="panel-title">How to play</p>
            <ul className="panel-list">
              <li>Move with `WASD` or arrow keys.</li>
              <li>Tap `Space` for a quick tongue strike.</li>
              <li>Collect 18 bugs before the timer ends.</li>
              <li>Water drops restore health.</li>
            </ul>
            <p className="panel-message">{message}</p>
            <div className="panel-actions">
              <button onClick={startGame}>Start</button>
              <button className="ghost" onClick={pauseGame} disabled={status === "ready" || status === "ended"}>
                {status === "paused" ? "Resume" : "Pause"}
              </button>
              <button className="ghost" onClick={resetRound}>Reset</button>
            </div>
            <div className="panel-footer">
              {status === "ended" && (
                <span>
                  {score >= TARGET_SCORE ? "You fed like a champ." : "Try for a higher score."}
                </span>
              )}
              {status === "ready" && <span>Press Start to begin the hunt.</span>}
              {status === "running" && <span>Target: {TARGET_SCORE} bugs.</span>}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
