import { requireAdmin } from "@/lib/auth";
import AdminClient from "./prompt-client";

export default function AdminPage() {
  requireAdmin();
  return (
    <main>
      <div className="shell">
        <div className="top-actions">
          <div className="header">
            <div className="title">Admin Prompt Editor</div>
            <div className="subtitle">Update the system prompt without redeploying.</div>
          </div>
        </div>
        <AdminClient />
      </div>
    </main>
  );
}
